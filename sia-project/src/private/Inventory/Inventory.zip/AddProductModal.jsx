import React, { useState, useEffect, useRef } from "react";

const AddProductModal = ({ onClose, onSave }) => {
  const [product, setProduct] = useState({
    id: "",
    genericName: "",
    brandName: "",
    unitOfMeasurement: "",
    packing: "",
    lotNum: "",
    stock: 0,
    expiryDate: "",
    image: "",
  });

  const fileInputRef = useRef();

  useEffect(() => {
    const newId = `NPROD-${Math.floor(1000 + Math.random() * 9000)}`;
    setProduct((prev) => ({ ...prev, id: newId }));
  }, []);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setProduct({ ...product, [name]: value });
  };

  const handleImageChange = (e) => {
    const file = e.target.files[0];
    if (!file) return;

    const img = new Image();
    const reader = new FileReader();

    reader.onload = (event) => {
      img.src = event.target.result;

      img.onload = () => {
        const canvas = document.createElement("canvas");
        const size = 300;
        canvas.width = size;
        canvas.height = size;

        const ctx = canvas.getContext("2d");
        const ratio = Math.min(size / img.width, size / img.height);
        const newWidth = img.width * ratio;
        const newHeight = img.height * ratio;
        const xOffset = (size - newWidth) / 2;
        const yOffset = (size - newHeight) / 2;

        ctx.fillStyle = "#fff";
        ctx.fillRect(0, 0, size, size);
        ctx.drawImage(img, xOffset, yOffset, newWidth, newHeight);

        const resizedDataUrl = canvas.toDataURL("image/jpeg");
        setProduct((prev) => ({
          ...prev,
          image: resizedDataUrl,
        }));
      };
    };

    reader.readAsDataURL(file);
  };

  const handleSave = () => {
    if (
      !product.genericName ||
      !product.brandName ||
      !product.unitOfMeasurement ||
      !product.packing ||
      !product.lotNum ||
      product.stock <= 0 ||
      !product.expiryDate
    )
      return;

    onSave({ ...product, stock: Number(product.stock) });
    onClose();
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex justify-center items-center z-50">
      <div className="bg-white p-6 rounded-lg shadow-lg w-full max-w-lg text-gray-900">
        <h2 className="text-xl font-bold text-center mb-4">Add New Product</h2>

        <table className="w-full text-sm border border-gray-300 mb-4">
          <tbody>
            <tr>
              <td className="border px-4 py-2 font-medium w-1/3">Product ID</td>
              <td className="border px-4 py-2">
                <input
                  type="text"
                  value={product.id}
                  readOnly
                  className="w-full border px-2 py-1 text-gray-900 bg-gray-100"
                />
              </td>
            </tr>
            <tr>
              <td className="border px-4 py-2 font-medium">Generic Name</td>
              <td className="border px-4 py-2">
                <input
                  type="text"
                  name="genericName"
                  value={product.genericName}
                  onChange={handleChange}
                  className="w-full border px-2 py-1 text-gray-900 bg-white"
                />
              </td>
            </tr>
            <tr>
              <td className="border px-4 py-2 font-medium">Brand Name</td>
              <td className="border px-4 py-2">
                <input
                  type="text"
                  name="brandName"
                  value={product.brandName}
                  onChange={handleChange}
                  className="w-full border px-2 py-1 text-gray-900 bg-white"
                />
              </td>
            </tr>
            <tr>
              <td className="border px-4 py-2 font-medium">Unit</td>
              <td className="border px-4 py-2">
                <select
                  name="unitOfMeasurement"
                  value={product.unitOfMeasurement}
                  onChange={handleChange}
                  className="w-full border px-2 py-1 text-gray-900 bg-white"
                >
                  <option value="">Select Unit</option>
                  <option value="Tablet">Tablet</option>
                  <option value="Capsule">Capsule</option>
                  <option value="Bottle">Bottle</option>
                  <option value="Syringe">Syringe</option>
                  <option value="Box">Box</option>
                  <option value="Ampoule">Ampoule</option>
                  <option value="Other">Other</option>
                </select>
              </td>
            </tr>
            <tr>
              <td className="border px-4 py-2 font-medium">Packing</td>
              <td className="border px-4 py-2">
                <input
                  type="text"
                  name="packing"
                  value={product.packing}
                  onChange={handleChange}
                  className="w-full border px-2 py-1 text-gray-900 bg-white"
                />
              </td>
            </tr>
            <tr>
              <td className="border px-4 py-2 font-medium">Lot Number</td>
              <td className="border px-4 py-2">
                <input
                  type="text"
                  name="lotNum"
                  value={product.lotNum}
                  onChange={handleChange}
                  className="w-full border px-2 py-1 text-gray-900 bg-white"
                />
              </td>
            </tr>
            <tr>
              <td className="border px-4 py-2 font-medium">Stock</td>
              <td className="border px-4 py-2">
                <input
                  type="number"
                  name="stock"
                  value={product.stock}
                  onChange={handleChange}
                  className="w-full border px-2 py-1 text-gray-900 bg-white"
                />
              </td>
            </tr>
            <tr>
              <td className="border px-4 py-2 font-medium">Expiry Date</td>
              <td className="border px-4 py-2">
                <input
                  type="date"
                  name="expiryDate"
                  value={product.expiryDate}
                  onChange={handleChange}
                  className="w-full border px-2 py-1 text-gray-900 bg-white"
                />
              </td>
            </tr>
            <tr>
              <td className="border px-4 py-2 font-medium">Image</td>
              <td className="border px-4 py-2">
                <input
                  type="file"
                  accept="image/*"
                  onChange={handleImageChange}
                  ref={fileInputRef}
                  className="w-full"
                />
                {product.image && (
                  <img
                    src={product.image}
                    alt="Preview"
                    className="mt-2 w-32 h-32 object-cover border rounded"
                  />
                )}
              </td>
            </tr>
          </tbody>
        </table>

        <div className="flex justify-end space-x-2 mt-4">
          <button
            className="bg-green-500 text-white px-5 py-2 rounded hover:bg-green-600"
            onClick={handleSave}
          >
            Save
          </button>
          <button
            className="bg-red-500 text-white px-5 py-2 rounded hover:bg-red-600"
            onClick={onClose}
          >
            Cancel
          </button>
        </div>
      </div>
    </div>
  );
};

export default AddProductModal;
